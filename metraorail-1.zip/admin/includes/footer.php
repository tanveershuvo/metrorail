</div>
<footer class="main-footer" style="background-color: lightgray">
<div class="pull-right hidden-xs">
  All rights
 reserved.
</div>
<strong>Copyright &copy; 2014-2019 Metrorail</strong>
</footer>


</div>
<!-- ./wrapper -->
<script>
setTimeout(function() {
    $('.msg').fadeOut(1000);
}, 1500);

</script>
<!-- jQuery 3 -->
<script src="../bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="../bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- DataTables -->
<script src="../bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>

<script type="text/javascript" src="../clock-picker/dist/bootstrap-clockpicker.min.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
})
</script>
