<?php
include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'includes/sidebar.php';
include_once("dbCon.php");
$conn =connect();
?>

    <!-- Start Content -->
    <div id="content">
      <div class="container">
          <div class="col-sm-12 page-content">
            <div class="inner-box">
              <div class="text-center">
               <h2>Balance :<b style="color:red;"> 300 ৳</b></h2>
              </div>
            </div>
              <div class="inner-box">
                <h2 class="title-2"><i class="fa fa-credit-card"></i> Transaction History</h2>
                <div class="table-responsive">

                  <table class="table table-striped table-bordered add-manage-table">
                    <thead>
                      <tr>
                        <th data-type="numeric">No</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Card type</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td ></td>
                        <td ></td>
                        <td ></td>
                        <td ></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- End Content -->
    <?php
    include_once 'includes/footer.php';
    ?>
