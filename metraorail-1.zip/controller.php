<?php
session_start();
if(isset($_POST['search'])){
  $_SESSION['source'] = $_POST['source'];
  $_SESSION['destination'] = $_POST['destination'];
  $_SESSION['time'] = $_POST['time'];
  header('Location:index');
}

if(isset($_POST['calculate'])){
  $_SESSION['source'] = $_POST['source'];
  $_SESSION['destination'] = $_POST['destination'];
  header('Location:fareMeter');
}



 ?>
